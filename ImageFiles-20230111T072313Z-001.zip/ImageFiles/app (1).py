
from flask import Flask,request,jsonify,redirect,url_for,render_template
#from __future__ import division,print_function
from werkzeug.utils import secure_filename
import gevent
from gevent.pywsgi import WSGIServer
import tensorflow as tf
from tensorflow import keras
#with keras.utils.custom_object_scope
import joblib
import os
from io import BytesIO
import sys
from PIL import Image
import glob
import numpy as np
import re
from keras.applications.imagenet_utils import preprocess_input,decode_predictions
from keras.models import load_model
from keras.preprocessing import image

#import BytesIO
import requests


app = Flask(__name__)
#model = joblib.load("model.pkl")
#model_path = 'model.h5'

model = load_model('model.h5')
#model.make_predict_function()
print('Model loaded')
data_labels = []
rootdir = 'train/'
for file in os.listdir(rootdir):
    d = os.path.join(rootdir, file)
    if os.path.isdir(d):
        data_labels.append(d[6:])

@app.route('/predictImageLabel', methods=['POST'])
def predict_image_label():
    data = request.get_json()
    url = data['image_url']
    response = requests.get(url)
    img = Image.open(BytesIO(response.content))
    IMAGE_SHAPE = (224,224)
    image_to_predict = img.resize(IMAGE_SHAPE)
    image_to_predict = np.array(image_to_predict) / 255.0
    final_img = image_to_predict[np.newaxis, ...]
    result = model.predict(final_img)
    predicted_label_index = np.argmax(result)

    model_result = {"label":data_labels[predicted_label_index]}
    return jsonify(model_result)

if __name__ == "__main__":
    app.run(host = '0.0.0.0',port = 8009,debug=True)