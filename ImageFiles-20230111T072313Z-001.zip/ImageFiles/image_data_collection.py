import os
import requests
from bs4 import BeautifulSoup

google_image = "https://www.google.com/search?site=&tbm=isch&source=hp&biw=1873&bih=990&"

user_agent = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36"
}


data_labels = []
rootdir = 'C:/Users/lenovo/Desktop/train'
for file in os.listdir(rootdir):
    d = os.path.join(rootdir, file)
    if os.path.isdir(d):
        data_labels.append(d[6:])

with open('new_classes.txt') as f:
    classes = f.read().splitlines()
classes = ['switch board','remote','knife','plate','stove','exhaust fan','ironbox','fridge','washing machine','oven','fan','air conditioner','mixer grinder','tube light','bulb','cup','table','chair','bed','cupboard','mirror','television','laptop','computer','keyboard','mouse','sofa','window','curtain','doormat','shoes','lipstick','earrings','pillow']
#classes = ['Knife']
classes = [item for item in classes if item not in data_labels]

saved_folder = 'train'
def download_images():
    for data in classes:
        n_images = 100
        folder_path = saved_folder+"/"+data+"/"
        if not os.path.exists(folder_path):
            os.mkdir(folder_path)

        print(f'searching for {data}...')

        search_url = google_image + 'q=' + data

        response = requests.get(search_url, headers=user_agent)

        html = response.text

        soup = BeautifulSoup(html, 'html.parser')

        results = soup.findAll('img', {'class': 'rg_i Q4LuWd'})

        count = 1
        links = []
        for result in results:
            try:
                link = result['data-src']
                links.append(link)
                count += 1
                if(count > n_images):
                    break

            except KeyError:
                continue

        print(f"Downloading {len(links)} images...")

        for i, link in enumerate(links):
            response = requests.get(link)

            image_name = folder_path + str(i+1) + '.jpg'

            with open(image_name, 'wb') as fh:
                fh.write(response.content)

def main():
    

    if not os.path.exists(saved_folder):
        os.mkdir(saved_folder)
    download_images()

if __name__ == "__main__":
    main()
