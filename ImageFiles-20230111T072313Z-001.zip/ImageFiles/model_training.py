import numpy as np
import cv2

import PIL.Image as Image
import os
from os import path
from shutil import disk_usage

import tensorflow as tf
import tensorflow_hub as hub

# from tensorflow import keras
# from tensorflow.keras import layers
# from tensorflow.keras.models import Sequential
import pathlib
import joblib

import requests
from io import BytesIO

from sklearn.model_selection import train_test_split
# X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=0)

IMAGE_SHAPE = (224,224)
model = tf.keras.Sequential([
    hub.KerasLayer("https://tfhub.dev/google/tf2-preview/mobilenet_v2/classification/4", input_shape = IMAGE_SHAPE+(3,))
])

data_dir = pathlib.Path("train")


data_labels = []
rootdir = 'train/'
for file in os.listdir(rootdir):
    d = os.path.join(rootdir, file)
    if os.path.isdir(d):
        data_labels.append(d[6:])

images_dict = {}
for label in data_labels:
    images_dict[label] = list(data_dir.glob(f"{label}/*"))

image_labels_dict = {}
for index,label in enumerate(data_labels):
    image_labels_dict[label] = index


X,y = [],[]

for label_name,images in images_dict.items():
    for image in images:
        try:
            print(f"resizing image {str(image)}")
            img = cv2.imread(str(image))
            resized_img = cv2.resize(img,IMAGE_SHAPE)
            X.append(resized_img)
            y.append(image_labels_dict[label_name])
        except Exception as e:
            print(str(e))


X = np.array(X)
y = np.array(y)

X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=0)

X_train_scaled = X_train/255.0
X_test_scaled = X_test/255.0

feature_extractor_model = "https://tfhub.dev/google/tf2-preview/mobilenet_v2/feature_vector/4"
transfer_learning_model_without_top_layer = hub.KerasLayer(feature_extractor_model, input_shape = (224,224,3),
                   trainable=False)


num_of_labels = len(data_labels)
model = tf.keras.Sequential([
    transfer_learning_model_without_top_layer,
    tf.keras.layers.Dense(num_of_labels)
])
print(model.summary())


model.compile(
    optimizer="adam",
    loss = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
    metrics = ['acc'])

print("Training...")
model.fit(X_train_scaled,y_train,epochs = 1)
model.save('model.h5')
#joblib.dump(model, 'model.pkl')